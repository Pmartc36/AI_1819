import numpy as np
import math

def backpropogate(x, y):
    N = 2
    lambda_val = 0.1

    while True:
        #for L in range(0, N):
            #print()

        first_layer = [w0, b1, x]
        second_layer = [w1, b2, 0]
        output = [0]
        layers = [first_layer, second_layer, output]
        dot_N = 0

        for epoch in range(0, 2):
            for layer_num in range(1, N+1):
                inputvec = layers[layer_num-1][-1]
                weightvec = layers[layer_num-1][0]
                dot_L = inputvec * weightvec + layers[layer_num-1][1]
                if layer_num == 2:
                    dot_N = dot_L
                A_matrix = np.vectorize(A)
                a_L = A_matrix(dot_L)
                if layer_num == 2:
                    layers[layer_num][0] = a_L
                else:
                    layers[layer_num][2] = a_L

            del_L = []
            A_prime_matrix = np.vectorize(A_prime)
            del_N = np.multiply(A_prime_matrix(dot_N), y-layers[-2][-1])
            del_L.append(del_N)
            for L in range(N-1, 0, -1):
                del_L.insert(0, np.multiply(A_prime_matrix(layers[L][-1]), del_L[0]) * (layers[L][0]).transpose())
            index = 0
            for L in range(N - 1, -1, -1):
                layer = layers[L]
                new_weight = layer[0] + lambda_val * layer[-1].transpose() * del_L[index]
                new_bias = layer[1] + lambda_val * del_L[index]
                layers[L][0] = new_weight
                layers[L][1] = new_bias
            print(y - layers[-1][0])
        break


def A(input):
    return 1/(1+math.e**(-1*input))

def A_prime(input):
    sigmoid_val = A(input)
    return sigmoid_val*(1-sigmoid_val)

w0 = np.matrix([[-1,-.5],[1,.5]])
w1 = np.matrix([[1,2],[-1,-2]])
b1 = np.matrix([1,-1])
b2 = np.matrix([-.5,.5])
x = np.matrix([[2,3]])
y = np.matrix([.8,1])

backpropogate(x, y)


