import numpy as np
import math
import random

def backpropogation():
    x = [[0, 0], [0, 1], [1, 0], [1, 1]]
    y = [[0, 0], [0, 1], [0, 1], [1, 0]]
    lambdaval = 0.1
    total_error = 10

    while total_error > 0.015:
        w_0 = np.matrix([[random.random(), random.random()], [random.random(), random.random()]])
        w_1 = np.matrix([[random.random(), random.random()],  [random.random(), random.random()]])
        b_1 = np.matrix([[random.random(), random.random()]])
        b_2 = np.matrix([[random.random(), random.random()]])

        A_matrix = np.vectorize(A)
        A_prime_matrix = np.vectorize(A_prime)

        for epoch in range(10000):
            for num in range(4):
                input = np.matrix(x[num])
                output = np.matrix(y[num])

                a_0 = np.matrix(input)
                dot_1 = a_0 * w_0 + b_1
                a_1 = A_matrix(dot_1)
                dot_2 = a_1 * w_1 + b_2
                a_2 = A_matrix(dot_2)

                del_2 = np.multiply(A_prime_matrix(dot_2), output - a_2)
                del_1 = np.multiply(A_prime_matrix(dot_1), del_2 * w_1.transpose())

                w_0 = w_0 + lambdaval * a_0.transpose() * del_1
                w_1 = w_1 + lambdaval * a_1.transpose() * del_2
                b_1 = b_1 + lambdaval * del_1
                b_2 = b_2 + lambdaval * del_2

                dot_1 = a_0 * w_0 + b_1
                a_1 = A_matrix(dot_1)
                dot_2 = a_1 * w_1 + b_2
                a_2 = A_matrix(dot_2)

                total_error += 0.5 * np.linalg.norm(output - a_2) ** 2
            print(total_error)
            total_error = 0


        round_matrix = np.vectorize(round)
        for input in x:
            a_0 = np.matrix(input)
            dot_1 = a_0 * w_0 + b_1
            a_1 = A_matrix(dot_1)
            dot_2 = a_1 * w_1 + b_2
            a_2 = A_matrix(dot_2)

            print(a_0, a_2, round_matrix(a_2))





def A(x):
    return 1/(1+math.e ** -x)

def A_prime(x):
    return (math.e ** (-x)) / ((1 + math.e ** -x) ** 2)

def round(x):
    if x < .5:
        return 0
    return 1

backpropogation()