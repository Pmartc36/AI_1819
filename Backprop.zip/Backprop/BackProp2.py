import numpy as np
import math
import random

def backpropogate(x):
    N = 2
    lambda_val = 0.1

    while True:
        layers = [] #weight, bias, input
        layer_one = [np.matrix([[-1,1], [-1,1]]), np.matrix([1.5, -.5]), x]
        layer_two = [np.matrix([[1], [1]]), np.matrix([-1.5]), 0]
        output = [0]
        layers = [layer_one, layer_two, output]

        dot_N = 0

        for epoch in range(0, 2):
            for layer_num in range(1, N+1):
                inputvec = layers[layer_num-1][-1]
                weightvec = layers[layer_num-1][0]
                dot_L = inputvec * weightvec + layers[layer_num-1][1]
                if layer_num == 2:
                    dot_N = dot_L
                A_matrix = np.vectorize(A)
                a_L = A_matrix(dot_L)
                if layer_num == 2:
                    layers[layer_num][0] = a_L
                else:
                    layers[layer_num][2] = a_L
        print(layers[-1])


def A(input):
    if input > 0:
        return 1
    return 0


x = np.matrix([1, 0])
y = np.matrix([0, 1, 1, 0])

backpropogate(x)
