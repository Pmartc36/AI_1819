import matplotlib.pyplot as plt
import math
import numpy as np
import random

plt.axis([-2, 2, -2, 2])


def perceptron(w, b, x):
    inputt = 0
    for x_in in x:
        for i in range(0, len(w)):
            inputt += w[i] * float(x_in[i])
    inputt += b
    return A(inputt)


def neural_net(x_step, y_step, W):

    perceptron1 = perceptron((0, 1), 1, [[x_step, y_step]])
    perceptron2 = perceptron((0, -1), 1, [[x_step, y_step]])
    perceptron3 = perceptron((1, 0), 1, [[x_step, y_step]])
    perceptron4 = perceptron((-1, 0), 1, [[x_step, y_step]])
    perceptron5 = perceptron((W[0], W[1], W[2], W[3]), 3.5, [[perceptron1, perceptron2, perceptron3, perceptron4]])

    return perceptron5


def A(inputt):
    k = 3
    return 1 / (1 + math.e ** (-inputt * k))


def hillclimb(X, epsilon):  # NN, describes the entire neural net, taking in some number of inputs for each perceptron, X refers to the set of test values vectors for input, w refers to the set of all weight vectors
    W = [random.uniform(-1, 1), random.uniform(-1, 1), random.uniform(-1, 1), random.uniform(-1, 1)]
    while True:
        lambda_val = 0.2
        W2 = [lambda_val * random.uniform(-1, 1) + W[0], lambda_val * random.uniform(-1, 1) + W[1], lambda_val * random.uniform(-1, 1) + W[2], lambda_val * random.uniform(-1, 1) + W[3]]
        error_W = error(X, W)
        error_W2 = error(X, W2)
        if error_W2 < error_W:
            W = W2
            error_W = error_W2
            print(error_W, W)
        if error_W < epsilon:
            return W


def error(X, W):
    total_error = 0
    for input_coord in X:
        x_step = input_coord[0]
        y_step = input_coord[1]
        in_circle = X[input_coord]
        neural_net_eval = neural_net(x_step, y_step, W)
        if in_circle:
            total_error += math.fabs(1 - neural_net_eval)
        else:
            total_error += math.fabs(0 - neural_net_eval)
    return total_error


def perceptron_line(w, b, x):
    inputt = 0
    for x_in in x:
        for i in range(0, len(w)):
            inputt += w[i] * float(x_in[i])
    inputt += b
    return int(inputt > 0)


def train(w, b, table):
    for epoch in range(100):
        for x, y in table:
            y_star = perceptron(w, b, [x])
            error = y - y_star
            new_w = []
            for index in range(len(w)):
                new_w.append(w[index] + error * int(x[index]))
            w = new_w
            b += error
    return (w, b)


def truth_table(bits, n):
    dict_dec_to_bin = dict()  # this associates each decimal value in the range of 0 to 2^bits with a 2^bits long string
    length = 2 ** bits
    truth_table_n = list()
    for num in range(0, length):
        binary = bin(num)
        binary = binary[binary.find("b") + 1:]
        binary = (bits - len(binary)) * "0" + binary
        dict_dec_to_bin[num] = list(binary)
    for num in range(length - 1, -1, -1):
        if 2 ** num <= n:
            n -= 2 ** num
            truth_table_n.append((dict_dec_to_bin[num], 1))
        else:
            truth_table_n.append((dict_dec_to_bin[num], 0))
    return truth_table_n


def pretty_print_tt(truth_table):
    for num in truth_table:
        string = ""
        string += str(num[0]) + " | " + str(num[1])
        print(string)


def check(n, w, b):
    bits = len(w)
    this_truth_table = truth_table(bits, n)
    check_dict = dict()
    for num in this_truth_table:
        check_dict[tuple(num[0])] = num[1]
    for num in this_truth_table:
        val = 0
        for vector_component in range(0, len(num[0])):
            val += w[vector_component] * int(num[0][vector_component])
        val += b
        if val > 0:
            check_dict[tuple(num[0])] = 1
        else:
            check_dict[tuple(num[0])] = 0
    total_accurate = 0
    total = len(this_truth_table)
    for num in this_truth_table:
        if check_dict[tuple(num[0])] == num[1]:
            total_accurate += 1

    if total_accurate // total == 1:
        return True
    return False


def frange(x, y, jump):
    while x < y:
        yield x
        x += jump


bits = 2
num = 8

out_set = set()
in_set = set()
out_match_set = set()
in_match_set = set()

training_set = []
training_dict = dict()
with open("10000_pairs.txt", "r") as f:
    for line in f:
        xs, ys = line.split()
        x, y = float(xs), float(ys)
        answer = True if x ** 2 + y ** 2 <= 1 else False
        training_set.append(tuple(((x, y), answer)))
        training_dict[(x, y)] = answer
training_set = tuple(training_set)

hillclimb(training_dict, 100)
