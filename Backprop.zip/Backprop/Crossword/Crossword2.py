import sys
import re
import random
from collections import deque
import copy


def print_board(board, rows, cols):
    rowString = ""
    for x in range(0, rows):
        line = ""
        for y in range(0, cols):
            line += board[x * cols + y]
        print(line)


def does_not_block_section(rows, cols, blocked, blockable):
    visited = set()
    if len(blockable) == 0:
        return True
    start = random.choice(tuple(blockable))
    bfs_queue = deque([(start, (start - cols, start + cols, start + 1, start - 1))])
    visited.add(start)
    while len(bfs_queue) != 0:
        surroundings = bfs_queue.popleft()
        for sur in surroundings[1]:
            if sur >= 0 and sur < rows * cols and sur not in blocked and sur not in visited and not (
                    sur % cols == cols - 1 and surroundings[0] % cols == 0) and not (
                    surroundings[0] % cols == cols - 1 and sur % cols == 0):
                bfs_queue.append((sur, (sur - cols, sur + cols, sur + 1, sur - 1)))
                visited.add(sur)
    total = set()
    for i in range(0, rows * cols):
        total.add(i)
    not_visited = total.difference(visited)
    if rows * cols - len(blocked) == len(visited):
        return True
    return False


def setup(rows, cols, initial_words, num_blocks):  # input string will contain the full input given by the code
    num_blocks_initial = num_blocks
    board = "." * rows * cols
    board_list = list(board)
    blocked_places = set()
    blockable = set()
    for i in range(0, rows * cols):
        blockable.add(i)
    if rows % 2 == 1 and cols % 2 == 1 and num_blocks % 2 == 1:
        center = (rows // 2) * cols + (cols // 2)
        board_list[center] = "#"
        result = blocker(center, blockable, blocked_places, num_blocks, rows, cols)
        blockable.remove(center)
        blocked_places.add(center)
        blockable = result[0]
        blocked_places = result[1]
        num_blocks = result[2]
        for i in blocked_places:
            board_list[i] = "#"

    for word in initial_words:
        direction = word[0]
        crossindex = word.index("x")
        x_start = int(word[1:crossindex])
        m = (re.search("\D", word[crossindex + 1:])).start() + crossindex + 1
        y_start = int(word[crossindex + 1:m])
        word_start = x_start * cols + y_start  # break up the initial words into several smaller components
        if direction == "V" or direction == "v":
            for num in range(0, len(word[m:])):
                board_list[word_start + num * cols] = word[m + num]
                if word[m + num] == "#":
                    result = blocker(word_start + num * cols, blockable, blocked_places, num_blocks, rows, cols)
                    blockable = result[0]
                    blocked_places = result[1]
                    for i in blocked_places:
                        if board_list[i] != "." and board_list[i] != "#":
                            return None
                        board_list[i] = "#"
                    num_blocks = result[2]
                blockable = blockable.difference(blocked_places)
                if word_start + num * cols in blockable:
                    blockable.remove(word_start + num * cols)

        if direction == "H" or direction == "h":
            for num in range(0, len(word[m:])):
                board_list[word_start + num] = word[m + num]
                if word[m + num] == "#":
                    result = blocker(word_start + num, blockable, blocked_places, num_blocks, rows, cols)
                    blockable = result[0]
                    blocked_places = result[1]
                    for i in blocked_places:
                        if board_list[i] != "." and board_list[i] != "#":
                            return None
                        board_list[i] = "#"
                    num_blocks = result[2]
                blockable = blockable.difference(blocked_places)
                if word_start + num in blockable:
                    blockable.remove(word_start + num)

    board = "".join(board_list)
    return board, blockable, blocked_places, num_blocks


def deepcopy_set(this_set):
    new_set = set()
    for i in this_set:
        new_set.add(i)
    return new_set


def finish_blocking(board_init, blockable_init, blocked_places_init, num_blocks, rows, cols):
    original_blockable = deepcopy_set(blockable_init)
    original_blocked_places = deepcopy_set(blocked_places_init)
    blocked_list = list(board_init)
    temp_num_blocks = num_blocks
    blockable = blockable_init.copy()
    blocked_places = blocked_places_init
    while temp_num_blocks != 0 or does_not_block_section(rows, cols, blocked_places, blockable) == False:
        if temp_num_blocks < 0:
            blockable = original_blockable.copy()
            blocked_places = original_blocked_places.copy()
            temp_num_blocks = num_blocks
            blocked_list = list(board_init)

        random_index = random.choice(tuple(blockable))
        while blocked_list[random_index] != ".":
            random_index = random.choice(tuple(blockable))
        result = blocker(random_index, blockable, blocked_places, temp_num_blocks, rows, cols)
        blockable = result[0]
        blocked_places = result[1]
        temp_num_blocks = result[2]
        if result[2] < 0:
            continue

        for index in blocked_places:
            blocked_list[index] = "#"

    new_board = "".join(blocked_list)
    return new_board, blocked_places


def blocker(index, blockable, blocked_places, num_blocks, rows, cols):
    word_queue = deque([index])
    visited = set()

    while len(word_queue) != 0:
        this_index = word_queue.popleft()
        flip = rows * cols - this_index - 1
        if this_index in blocked_places:
            continue
        if this_index != flip:
            num_blocks -= 2
        else:
            num_blocks -= 1
        blocked_places.add(this_index)
        blocked_places.add(flip)
        visited.add(this_index)
        visited.add(flip)

        index_row = this_index // cols
        index_col = this_index % cols
        for up in range(3, 0,
                        -1):  # check all indexes above the current word character, ensure that there is no block or edge
            new_index = this_index - cols * up
            if new_index < 0:
                n = 1
                while this_index - cols * n >= 0:
                    if (this_index - cols * n) not in visited and (this_index - cols * n) not in blocked_places and (
                            this_index - cols * n) not in word_queue:
                        word_queue.append(this_index - cols * n)
                    n += 1
                break
            elif new_index in blocked_places:
                for j in range(up, 0, -1):
                    if (this_index - cols * j) not in visited and (this_index - cols * j) not in blocked_places and (
                            this_index - cols * j) not in word_queue:
                        word_queue.append(this_index - cols * j)
                break

        for down in range(3, 0, -1):
            new_index = this_index + cols * down
            if new_index >= rows * cols:
                n = 1
                while this_index + cols * n < rows * cols:
                    if (this_index + cols * n) not in visited and (this_index + cols * n) not in blocked_places and (
                            this_index + cols * n) not in word_queue:
                        word_queue.append(this_index + cols * n)
                    n += 1
                break
            elif new_index in blocked_places:
                for j in range(down, 0, -1):
                    if (this_index + cols * j) not in visited and (this_index + cols * j) not in blocked_places and (
                            this_index + cols * j) not in word_queue:
                        word_queue.append(this_index + cols * j)
                break
        for left in range(3, 0, -1):
            new_index = this_index - left
            if new_index // cols != index_row:
                for j in range(index_row * cols, this_index):
                    if j not in visited and j not in blocked_places and j not in word_queue:
                        word_queue.append(j)
                break
            elif new_index in blocked_places or new_index in visited:
                for j in range(left, 0, -1):
                    if (this_index - j) not in visited and (this_index - j) not in blocked_places and (
                            this_index - j) not in word_queue:
                        word_queue.append(this_index - j)
                break
        for right in range(3, 0, -1):
            new_index = this_index + right
            if new_index // cols != index_row:
                for j in range(this_index + 1, (index_row + 1) * cols):
                    if j not in visited and j not in blocked_places and j not in word_queue:
                        word_queue.append(j)
                break
            elif new_index in blocked_places or new_index in visited:
                for j in range(right, 0, -1):
                    if (this_index + j) not in visited and (this_index + j) not in blocked_places and (
                            this_index + j) not in word_queue:
                        word_queue.append(this_index + j)
                break
    # blockable needs to be readjusted
    blockable = blockable.difference(blocked_places)
    return blockable, blocked_places, num_blocks


def choose_rand_available_position(board, rows, cols):  # board must be updated with all current letters to work

    positions = set()
    letter_indexes = set()
    for i in range(rows * cols):
        if board[i] != "." and board[i] != "#":
            letter_indexes.add(i)
            if i - cols >= 0:
                if board[i - cols] == ".":
                    positions.add(i - cols)
            if i + cols < rows * cols:
                if board[i + cols] == ".":
                    positions.add(i + cols)
            if ((i - 1) // cols) == (i // cols):
                if board[i - 1] == ".":
                    positions.add(i - 1)
            if ((i + 1) // cols) == (i // cols):
                if board[i + 1] == ".":
                    positions.add(
                        i + 1)  # good for choosing first position, not good for choosing next one because its better to build off what the board already has

    return positions, letter_indexes


def fill_crossword():
    if board.find(".") == -1:
        return True, board

    # pick the next location for a letter

    # determine all possible matches for each location

    matches = []

    index_row = fill_index // cols
    index_col = fill_index % cols

    this_col = ""
    this_row = board[index_row * cols:(index_row + 1) * cols]
    for row in range(rows):
        this_col += board[index_row + row * cols]

    left_num = index_col
    while left_num > 0 and this_row[left_num] != "#":
        left_num -= 1
    right_num = index_col
    while right_num < len(this_row) and this_row[right_num] != "#":
        right_num += 1

    this_regex_row = ""
    for i in range(left_num, right_num + 1):
        if this_row[i] == ".":
            this_regex_row += "\w"
        if this_row[i].isalpha():
            this_regex_row += this_row[i]

    # go through each of the possible matches
    for match in matches:
        new_board_list = list(board)
        new_board_list[fill_index] = match
        new_board = "".join(new_board_list)
        # place a letter
        # if: a failure occurs with this match, continue with the next match
        result = fill_crossword(new_board, blocked, rows, cols, fill_index)
        if result[0] == True:
            return True, new_board
        else:
            continue
        # else: recur
        # if the recursion fails: go to the next board
        # if the recursion suceeds: return this board
    return False, board


def create_dictionary(dict_file):  # dict_len_to_word - dictionary that associates every length possible for a word to a set of words that have that length
    dict_len_to_word = dict()  # board - a string representation of the final board, this is supposed to be used towards generating a dictionary that can be used to match every possible word space with that of a regex
    checker = open(dict_file, "r")
    for word in checker.readlines():
        word = word.rstrip()
        length = len(word)
        if length not in dict_len_to_word.keys():
            dict_len_to_word[length] = set([word])
        else:
            dict_len_to_word[length].add(word)

    return dict_len_to_word
def create_regex_lines(rows, cols, board):
    possible_words = []
    for row in range(rows):
        row_string = board[row * cols:(row + 1) * cols]
        word_start = 0
        for index in range(len(row_string) + 1):
            if index == len(row_string):
                if word_start != len(row_string):
                    word_space = "H" + str(row) + "x" + str(word_start) + row_string[word_start:]
                    possible_words.append(word_space)
            elif row_string[index] == "#":
                if word_start != index:
                    word_space = "H" + str(row) + "x" + str(word_start) + row_string[word_start:index]
                    possible_words.append(word_space)
                word_start = index + 1

    dict_cols = dict()
    for col in range(0, cols):
        temp_index = col
        dict_cols[col] = list([temp_index])
        for row in range(0, rows - 1):
            temp_index += cols
            dict_cols[col].append(temp_index)
    for col in dict_cols:
        col_num = col
        col = dict_cols[col]
        word_start = col[0]
        word_start_row = word_start // cols
        word_space = ""
        for index in col:
            if board[index] == "#":
                if word_start != index:
                    word_space = "V" + str(word_start_row) + "x" + str(col_num) + word_space
                    possible_words.append(word_space)
                    word_space = ""
                word_start = index + cols
                word_start_row = word_start // cols
            else:
                word_space += board[index]
                if len(word_space) == len(col) or index // cols == rows - 1:
                    word_space = "V" + str(word_start_row) + "x" + str(col_num) + word_space
                    possible_words.append(word_space)
                    word_space = ""

    return possible_words
def add_word(rows, cols, board, possible_words, dictionary):

    board_list = list(board)
    least_dot = 1000000
    most_constrained_word = ""
    for word in possible_words:
        if word.count(".") < least_dot and word.count(".") != 0:
            least_dot = word.count(".")
            most_constrained_word = word
    direction = most_constrained_word[0]
    row = int(most_constrained_word[1])
    col = int(most_constrained_word[3])
    word = most_constrained_word[4:]
    len_word = len(word)
    word = "^" + word + "$"
    start_index = row * cols + col
    matches = []
    for dict_entry in dictionary[len_word]:
        result = re.search(word, dict_entry)
        if result != None:
            matches.append(result.string)
    if len(matches) == 0:
        return None
        #recursive structure is wack
    random_match = random.choice(matches)
    possible_words.remove(direction + str(row) + "x" + str(col) + word[1:-1])
    possible_words.append(direction + str(row) + "x" + str(col) + random_match)
    if direction == "H":
        for char in range(0, len_word):
            board_list[start_index+char] = random_match[char]
    if direction == "V":
        for char in range(0, len_word):
            board_list[start_index+char*cols] = random_match[char]
    new_possible_words = create_regex_lines(rows, cols, "".join(board_list))
    print(new_possible_words)
    print("".join(board_list))
    print_board("".join(board_list), rows, cols)
    print()
    result = add_word(rows, cols, "".join(board_list), new_possible_words, dictionary)
    while result == None:
        board_list = list(board)
        least_dot = 1000000
        most_constrained_word = ""
        for word in possible_words:
            if word.count(".") < least_dot and word.count(".") != 0:
                least_dot = word.count(".")
                most_constrained_word = word
        direction = most_constrained_word[0]
        row = int(most_constrained_word[1])
        col = int(most_constrained_word[3])
        word = most_constrained_word[4:]
        len_word = len(word)
        word = "^" + word + "$"
        start_index = row * cols + col
        matches = []
        for dict_entry in dictionary[len_word]:
            result = re.search(word, dict_entry)
            if result != None:
                matches.append(result.string)
        if len(matches) == 0:
            return None
            # recursive structure is wack
        random_match = random.choice(matches)
        possible_words.remove(direction + str(row) + "x" + str(col) + word[1:-1])
        possible_words.append(direction + str(row) + "x" + str(col) + random_match)
        if direction == "H":
            for char in range(0, len_word):
                board_list[start_index + char] = random_match[char]
        if direction == "V":
            for char in range(0, len_word):
                board_list[start_index + char * cols] = random_match[char]
        new_possible_words = create_regex_lines(rows, cols, "".join(board_list))
        print(new_possible_words)
        print("".join(board_list))
        print_board("".join(board_list), rows, cols)
        print()



    # if direction == "H":

    # if direction == "V":


if __name__ == '__main__':
    # dimensions = sys.argv[1]
    # index = dimensions.find("x")
    # rows = int(dimensions[0:index])
    # cols = int(dimensions[index + 1:])
    # numBlocks = int(sys.argv[2])
    dict_file = "twentyk.txt"
    # dict_file = sys.argv[3]


    rows = 4
    cols = 4
    numBlocks = 0

    initial_words = []
    # initial_words = []
    # for i in range(4, len(sys.argv)):
    #   initial_words.append(sys.argv[i])

    result = setup(rows, cols, initial_words, numBlocks)

    # print_board(result[0], rows, cols)
    # print()

    result_2 = finish_blocking(result[0], result[1], result[2], result[3], rows, cols)

    new_board = result_2[0]
    new_blocked = result_2[1]

    #print_board(new_board, rows, cols)

    dictionary = create_dictionary(dict_file)
    possible_words = create_regex_lines(rows, cols, new_board)
    result_3 = ""
    for i in new_board:
        if i == ".":
            result_3 += "-"
        else:
            result_3 += i
    print(result_3)
    print_board(result_3, rows, cols)
    # print()
    # print(result_2.count("#"))
    # print(numBlocks)
    # print(dict[0])
    # print(dict[1])
    add_word(rows, cols, new_board, possible_words, dictionary)
    # fill_crossword()