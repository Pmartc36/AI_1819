import re
import random
from collections import deque

def does_not_block_section(rows, cols, blocked):
    visited = set()
    start = random.randint(0, rows*cols)
    while start in blocked:
        start = random.randint(0, rows * cols)
    bfs_queue = deque([(start,(start-cols, start+cols, start+1, start-1))])
    visited.add(start)
    while len(bfs_queue) != 0:
        surroundings = bfs_queue.popleft()
        for sur in surroundings[1]:
            if not (sur < 0 or sur >= len(board) or (sur%cols == cols-1 and surroundings[0]%cols == 0) or (sur%cols == 0 and surroundings[0]%cols == cols-1) or sur in blocked):
                bfs_queue.append(sur)
                visited.add(sur)
    if rows*cols - len(blocked) == len(visited):
        return True
    return False
def setup(rows, cols, num_blocks, initial_words_list): #rows - int, cosl - int, num_blocks - int, initial_words_list - list of strings
    board = ("."*rows)*cols
    board_list = list(board)
    blockable = set()
    blocked = set()
    for i in range(0, rows*cols):
        blockable.add(i)
    if rows%2 == 1 and cols%2 == 1 and num_blocks%2 == 1:
        center = (rows//2)*cols+(cols//2)
        board_list[center] = "#"
        blockable.remove(center)
        blocked.add(center)
    for word in initial_words_list:
        direction = word[0]
        crossindex = word.index("x")
        x_start = int(word[1:crossindex])
        m = (re.search("\D", word[crossindex+1:])).start()+crossindex+1
        y_start = int(word[crossindex+1:m])
        word_start = x_start*cols+y_start
        if direction == "V":
            for num in range(0, len(word[m:])):
                board_list[word_start+num*cols] = word[m+num]
                if word[m+num] == "#":
                    blocked.add(m+num)
                blockable.remove(word_start+num*cols)
        if direction == "H":
            for num in range(0, len(word[m:])):
                board_list[word_start+num] = word[m+num]
                if word[m+num] == "#":
                    blocked.add(m+num)
                blockable.remove(word_start+num)
    board = "".join(board_list)
    return board, blockable, blocked
def blocker(rows, cols, board, blockable, blocked): # rows - int, cols - int, board - str, blockable - set, blocked - set
    # for i in blocked:
    #    listBlocks = mandatory_block(rows, cols, i, blockable)
    #    boardList = list(board)
    #    if listBlocks is not None:
    #        for i in listBlocks:
    #            boardList[i] = "#"
    #    else:
    #        return None
    blockable = blockable.difference(blocked)
    start = random.choice((blockable))
    blocked.add(start)
    listBlocks = mandatory_block(rows, cols, start, blockable)
    boardList = list(board)
    if listBlocks is not None:
        for i in listBlocks:
            boardList[i] = "#"
    blockable = blockable.difference(blocked)







def mandatory_block(rows, cols, index, blockable):
    listBlocks = set()
    flip = rows*cols - index - 1
    listBlocks.add(flip)
    if index%cols >= cols-3: #block right
        n = 0
        while (index + n)%cols != 0:
            listBlocks.add(index+n)
            n += 1
    if index%cols < 3: #block left
        n = 0
        while (index - n)%cols != cols - 1:
            listBlocks.add(index - n)
            n += 1
    if index < 3*cols: #block top
        n = 0
        while (index - n*cols) >= 0:
            listBlocks.add(index-n*cols)
            n += 1
    if index >= (rows-3)*cols: #block bottom
        n = 0
        while (index + n*cols) < len(board):
            listBlocks.add(index+n*cols)
            n += 1
    if listBlocks.issubset(blockable):
        return listBlocks
    return None
def print_board(board, rows, cols):
    rowString = ""
    for x in range(0, rows):
        line = ""
        for y in range(0, cols):
            line += board[x*cols+y]
        print(line)
if __name__ == '__main__':
    rows = 11
    cols = 13
    numBlock = 27


    board = setup(rows, cols, numBlock, ["H0x0begin", "V8x12end"])
    print_board(board[0], rows, cols)
    blocker(rows, cols, board[0], board[1], board[2])

